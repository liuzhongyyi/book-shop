create view bookView as
  select `bk`.`bookId`       AS `bookId`,
         `bk`.`bookName`     AS `bookName`,
         `bk`.`bookAuthor`   AS `bookAuthor`,
         `bk`.`bookPicture`  AS `bookPicture`,
         `bk`.`bookPrice`    AS `bookPrice`,
         `bk`.`bookContent`  AS `bookContent`,
         `bt`.`bookTypeName` AS `bookTypeName`
  from `bookShop`.`book` `bk`
         join `bookShop`.`booktype` `bt`
  where (`bk`.`bookTypeId` = `bt`.`bookTypeId`);

